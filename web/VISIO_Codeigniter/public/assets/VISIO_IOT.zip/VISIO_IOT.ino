#include <MFRC522.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

//configurar o WIFI
const char* ssid = "WIFI-EDUC";
const char* password = "ac3ce7ss0-EDUC";

// URL base da API
const char* serverUrl = "http://10.141.131.63/VISIO_Codeigniter/public/api/usuarios";

// URL para enviar o cartão para o login
const char* loginCartaoUrl = "http://10.141.131.63/VISIO_Codeigniter/public/login/cartao/enviar";

//define os pino SDA do leitor RFID
#define RFID_SDA 5

//define o pino do leitor rfid
#define RFID_RST 4

//define os pinos LEDS
#define LED_VERDE 12
#define LED_VERMELHO 13
#define BUZZER 21

//definir o id do sensor rfid
#define SENSOR_RFID_ID 3

//chamar o controlador do rfid
MFRC522 leitorRFID(RFID_SDA, RFID_RST);

//criar função para conectar no WIFI
void conectarWifi() {

  WiFi.begin(ssid, password);

  Serial.print("\nConectando ao Wi-Fi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.print(".");
  }

  Serial.print("\nWi-Fi conectado");
}

// Busca o usuário usando o UID do cartão na URL
bool buscarUsuario(String uid) {

  if (WiFi.status() != WL_CONNECTED) {

    Serial.println("Wi-Fi desconectado.");

    return false;
  }

  HTTPClient http;

  // Monta a URL com o UID do cartão
  String url = String(serverUrl) + "/" + uid;

  Serial.println("\nConsultando API:");
  Serial.println(url);

  http.begin(url);

  // Faz GET /api/usuarios/UID
  int codigoResposta = http.GET();

  Serial.print("\nCódigo HTTP recebido: ");
  Serial.println(codigoResposta);

  if (codigoResposta != 200) {

    Serial.println("Erro ao buscar usuário.");

    Serial.println("Resposta da API:");

    Serial.println(http.getString());

    http.end();

    return false;
  }

  // Pega os dados retornados pela API
  String resposta = http.getString();

  Serial.println("\nResposta da API:");
  Serial.println(resposta);

  StaticJsonDocument<2048> json;

  DeserializationError erro = deserializeJson(json, resposta);

  if (erro) {

    Serial.println("Erro ao interpretar o JSON.");

    http.end();

    return false;
  }

  // Mostra os dados do usuário encontrado
  Serial.println("\n==============================");
  Serial.println("USUÁRIO ENCONTRADO");
  Serial.println("==============================");

  Serial.print("Nome: ");
  Serial.println(json["NOME"].as<String>());

  Serial.print("CPF: ");
  Serial.println(json["CPF"].as<String>());

  Serial.print("E-mail: ");
  Serial.println(json["EMAIL"].as<String>());

  Serial.print("Cartão: ");
  Serial.println(json["CARTAO"].as<String>());

  Serial.print("Data de nascimento: ");
  Serial.println(json["DATA_NASCIMENTO"].as<String>());

  Serial.print("Telefone: ");
  Serial.println(json["TELEFONE"].as<String>());

  Serial.println("==============================");

  http.end();

  return true;
}

// Envia o cartão para o sistema de login
bool enviarCartao(String uid) {

  if (WiFi.status() != WL_CONNECTED) {

    Serial.println("Wi-Fi desconectado.");

    return false;
  }

  HTTPClient http;

  Serial.println("\nEnviando cartão para o login:");
  Serial.println(uid);

  http.begin(loginCartaoUrl);

  http.addHeader("Content-Type", "application/x-www-form-urlencoded");

  String dados = "uid=" + uid;

  int codigoResposta = http.POST(dados);

  Serial.print("Código HTTP recebido: ");
  Serial.println(codigoResposta);

  String resposta = http.getString();

  Serial.println("Resposta do servidor:");
  Serial.println(resposta);

  http.end();

  if (codigoResposta == 200) {

    Serial.println("Cartão enviado com sucesso.");

    return true;
  }

  Serial.println("Erro ao enviar cartão.");

  return false;
}

// Função que lê o código UID do cartão.
String lerUID() {

  String uid = "";

  for (byte i = 0; i < leitorRFID.uid.size; i++) {

    if (leitorRFID.uid.uidByte[i] < 0x10) {
      uid += "0";
    }

    uid += String(leitorRFID.uid.uidByte[i], HEX);

    if (i < leitorRFID.uid.size - 1) {
      uid += " ";
    }
  }

  return uid;
}

// Remove os espaços do UID
String converterUID(String uid) {

  uid.replace(" ", "");

  uid.toUpperCase();

  return uid;
}

// Cria uma função para indicar sucesso
void indicarSucesso() {

  digitalWrite(LED_VERDE, HIGH);
  digitalWrite(LED_VERMELHO, LOW);

  tone(BUZZER, 3000);

  delay(200);

  noTone(BUZZER);

  delay(1000);

  digitalWrite(LED_VERDE, LOW);
}

// Cria uma função para indicar erro
void indicarErro() {

  digitalWrite(LED_VERDE, LOW);
  digitalWrite(LED_VERMELHO, HIGH);

  for (int i = 0; i < 3; i++) {

    tone(BUZZER, 500);

    delay(200);

    noTone(BUZZER);

    delay(150);
  }

  digitalWrite(LED_VERMELHO, LOW);
}

//chama a função setup
void setup() {

  Serial.begin(115200);

  delay(1000);

  pinMode(LED_VERMELHO, OUTPUT);
  pinMode(LED_VERDE, OUTPUT);
  pinMode(BUZZER, OUTPUT);

  SPI.begin(18, 19, 23, RFID_SDA);

  leitorRFID.PCD_Init();

  delay(1000);

  conectarWifi();

  Serial.println("\nLeitor RFID iniciado");
  Serial.println("Aproxime o cartão ou tag");
}

//chamar função loop
void loop() {

  //verificar se o wifi esta conectado
  if (WiFi.status() != WL_CONNECTED) {

    Serial.print("\nWi-Fi desconectado. Reconectando...");

    conectarWifi();
  }

  // Verifica se existe um novo cartão
  if (!leitorRFID.PICC_IsNewCardPresent()) {
    return;
  }

  // Tenta realizar a leitura
  if (!leitorRFID.PICC_ReadCardSerial()) {
    return;
  }

  // Obtém o UID
  String uidLido = lerUID();

  Serial.print("\nUID identificado: ");
  Serial.println(uidLido);

  // Transforma "56 17 15 06" em "56171506"
  String cartaoLido = converterUID(uidLido);

  Serial.print("Cartão para consulta: ");
  Serial.println(cartaoLido);

  // Consulta diretamente:
  // /api/usuarios/56171506
  bool usuarioEncontrado = buscarUsuario(cartaoLido);

  if (usuarioEncontrado) {

    Serial.println("\nUsuário autorizado.");

    // Envia o cartão para o login
    bool cartaoEnviado = enviarCartao(cartaoLido);

    if (cartaoEnviado) {

      Serial.println("Login por cartão enviado com sucesso.");

      indicarSucesso();

    } else {

      Serial.println("Não foi possível enviar o cartão para o login.");

      indicarErro();
    }

  } else {

    Serial.println("\nUsuário não encontrado.");

    indicarErro();
  }

  // Encerra comunicação com o cartão
  leitorRFID.PICC_HaltA();

  leitorRFID.PCD_StopCrypto1();

  delay(1500);
}